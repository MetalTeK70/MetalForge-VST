Place legally owned or original WAV cabinet impulse responses here for reference. Load them from the plugin UI. No third-party IR files are included in this prototype.
