# MetalForgeVST — prototype v0.1

An original, experimental Windows VST3 electric-guitar effect built with JUCE 8. Includes eight starting presets spanning high-gain and dark clean sounds, waveshaping drive, tone filter, reverb, and a user-loadable WAV cabinet impulse response.

## Important limitations
This is **not** a production amp modeler. Presets are starting points, not exact artist emulations. No custom IR pack is bundled yet. Chorus, delay, sophisticated amplifier models, preset saving UI, and seamless switching are future milestones. Without a loaded IR the convolution stage passes audio through. There is no acoustic-guitar simulation.

## GitHub build
Upload **the contents of this folder**, including the hidden `.github` folder, to your repository root. On GitHub open **Actions → Build Windows VST3 → Run workflow**, or push a commit. When successful, download the artifact `MetalForgeVST-Windows-VST3`, unzip it, and copy the `.vst3` bundle to `C:\Program Files\Common Files\VST3`. Restart Cakewalk and rescan VST plugins.

## Local build
Requires CMake 3.22+, Git, Visual Studio C++ build tools. Configure with CMake and build target `MetalForgeVST_VST3`. The first configure fetches JUCE from GitHub.

## Licensing
JUCE has its own licensing terms (AGPLv3 or commercial licensing depending on use). Review https://juce.com/legal/ before distributing proprietary binaries. This project includes no third-party artist recordings or commercial IRs.
