#include "PluginProcessor.h"
#include "PluginEditor.h"
namespace {
juce::AudioProcessorValueTreeState::ParameterLayout params(){
 std::vector<std::unique_ptr<juce::RangedAudioParameter>> p;
 auto add=[&](const char* id,const char* name,float min,float max,float initial){p.push_back(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{id,1},name,juce::NormalisableRange<float>(min,max),initial));};
 add("gain","Input Gain",0.1f,20.f,3.f);add("drive","Drive",0.f,1.f,0.65f);add("tone","Tone",500.f,14000.f,6500.f);add("mix","Wet Mix",0.f,1.f,1.f);add("reverb","Reverb",0.f,0.8f,0.15f);add("level","Output Level",0.f,1.f,0.45f);
 return {p.begin(),p.end()};
}
float get(juce::AudioProcessorValueTreeState& s,const char* key){return s.getRawParameterValue(key)->load();}
}
MetalForgeProcessor::MetalForgeProcessor():AudioProcessor(BusesProperties().withInput("Input",juce::AudioChannelSet::stereo(),true).withOutput("Output",juce::AudioChannelSet::stereo(),true)),state(*this,nullptr,"PARAMETERS",params()){}
bool MetalForgeProcessor::isBusesLayoutSupported(const BusesLayout& b) const {return b.getMainInputChannelSet()==b.getMainOutputChannelSet() && (b.getMainOutputChannelSet()==juce::AudioChannelSet::mono()||b.getMainOutputChannelSet()==juce::AudioChannelSet::stereo());}
void MetalForgeProcessor::prepareToPlay(double sr,int block){sampleRateHz=sr;juce::dsp::ProcessSpec spec{sr,(juce::uint32)block,(juce::uint32)getTotalNumOutputChannels()};convolution.prepare(spec);reverb.prepare(spec);reverb.reset();for(auto& f:lowpass){f.reset();f.prepare({sr,(juce::uint32)block,1});}}
void MetalForgeProcessor::processBlock(juce::AudioBuffer<float>& buffer,juce::MidiBuffer&){juce::ScopedNoDenormals noDenormals;
 const auto channels=buffer.getNumChannels(); const auto samples=buffer.getNumSamples();
 const float gain=get(state,"gain"),drive=get(state,"drive"),mix=get(state,"mix"),level=get(state,"level");
 for(int ch=0;ch<channels;++ch){auto* data=buffer.getWritePointer(ch);for(int i=0;i<samples;++i){float dry=data[i];float x=std::tanh(dry*gain*(1.f+drive*15.f));data[i]=dry*(1.f-mix)+x*mix;}}
 auto cutoff=juce::dsp::IIR::Coefficients<float>::makeLowPass(sampleRateHz,get(state,"tone"));
 for(int ch=0;ch<channels;++ch){*lowpass[ch].coefficients=*cutoff;juce::dsp::AudioBlock<float> channelBlock(buffer);auto single=channelBlock.getSingleChannelBlock((size_t)ch);juce::dsp::ProcessContextReplacing<float> ctx(single);lowpass[ch].process(ctx);}
 juce::dsp::AudioBlock<float> block(buffer);juce::dsp::ProcessContextReplacing<float> ctx(block);convolution.process(ctx);
 juce::dsp::Reverb::Parameters rp;rp.roomSize=0.65f;rp.damping=0.45f;rp.wetLevel=get(state,"reverb")*0.4f;rp.dryLevel=1.f-rp.wetLevel;rp.width=1.f;reverb.setParameters(rp);reverb.process(ctx);
 buffer.applyGain(level);
}
bool MetalForgeProcessor::loadIR(const juce::File& f){if(!f.existsAsFile())return false;convolution.loadImpulseResponse(f,juce::dsp::Convolution::Stereo::yes,juce::dsp::Convolution::Trim::yes,0,juce::dsp::Convolution::Normalise::yes);return true;}
const juce::StringArray& MetalForgeProcessor::presetNames(){static const juce::StringArray names{"Industrial Crush","Progressive Lead","Doom Chamber","Haunted Cathedral","Gothic Glass","Midnight Arpeggio","Classic Clean","Funeral Rain"};return names;}
void MetalForgeProcessor::setPreset(int index){static const float presets[][6]={{7,.9f,7500,1,.07f,.35f},{5,.75f,9000,1,.18f,.38f},{9,.95f,3500,1,.22f,.4f},{1.2f,.02f,7500,.4f,.7f,.65f},{1.5f,.02f,11500,.35f,.5f,.65f},{1.7f,.07f,6500,.45f,.45f,.6f},{1.4f,.08f,9500,.4f,.2f,.65f},{1.3f,.02f,4300,.35f,.6f,.6f}};if(!juce::isPositiveAndBelow(index,8))return;const char* ids[]={"gain","drive","tone","mix","reverb","level"};for(int i=0;i<6;++i){auto* p=state.getParameter(ids[i]);p->setValueNotifyingHost(p->convertTo0to1(presets[index][i]));}}
void MetalForgeProcessor::getStateInformation(juce::MemoryBlock& dest){auto xml=state.copyState().createXml();copyXmlToBinary(*xml,dest);}
void MetalForgeProcessor::setStateInformation(const void* data,int size){auto xml=getXmlFromBinary(data,size);if(xml && xml->hasTagName(state.state.getType()))state.replaceState(juce::ValueTree::fromXml(*xml));}
juce::AudioProcessorEditor* MetalForgeProcessor::createEditor(){return new MetalForgeEditor(*this);}
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter(){return new MetalForgeProcessor();}
