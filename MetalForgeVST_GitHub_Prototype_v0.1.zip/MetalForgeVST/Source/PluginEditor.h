#pragma once
#include "PluginProcessor.h"
class MetalForgeEditor : public juce::AudioProcessorEditor {
public:
 explicit MetalForgeEditor(MetalForgeProcessor&);
 void resized() override;
 void paint(juce::Graphics&) override;
private:
 MetalForgeProcessor& processor;
 juce::ComboBox presets;
 juce::TextButton loadIRButton{"Load Cabinet IR (.wav)"};
 std::array<juce::Slider,6> sliders;
 std::array<juce::Label,6> labels;
 std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> attachments;
 JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(MetalForgeEditor)
};
