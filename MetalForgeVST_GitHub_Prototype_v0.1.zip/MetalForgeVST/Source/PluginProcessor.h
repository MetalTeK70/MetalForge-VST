#pragma once
#include <JuceHeader.h>
class MetalForgeProcessor : public juce::AudioProcessor {
public:
 MetalForgeProcessor();
 void prepareToPlay(double,int) override;
 void releaseResources() override {}
 bool isBusesLayoutSupported(const BusesLayout&) const override;
 void processBlock(juce::AudioBuffer<float>&,juce::MidiBuffer&) override;
 juce::AudioProcessorEditor* createEditor() override;
 bool hasEditor() const override {return true;}
 const juce::String getName() const override {return "MetalForgeVST";}
 bool acceptsMidi() const override {return false;}
 bool producesMidi() const override {return false;}
 bool isMidiEffect() const override {return false;}
 double getTailLengthSeconds() const override {return 2.0;}
 int getNumPrograms() override {return 1;}
 int getCurrentProgram() override {return 0;}
 void setCurrentProgram(int) override {}
 const juce::String getProgramName(int) override {return {};}
 void changeProgramName(int,const juce::String&) override {}
 void getStateInformation(juce::MemoryBlock&) override;
 void setStateInformation(const void*,int) override;
 juce::AudioProcessorValueTreeState state;
 bool loadIR(const juce::File&);
 void setPreset(int);
 static const juce::StringArray& presetNames();
private:
 juce::dsp::Convolution convolution;
 juce::dsp::Reverb reverb;
 juce::dsp::IIR::Filter<float> lowpass[2];
 double sampleRateHz=44100.0;
 JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(MetalForgeProcessor)
};
